from collections import deque
from typing import List, Optional

from maze_core import Grid, Pos

Path = List[Pos]


def solve(grid: Grid, start: Pos, goal: Pos) -> Optional[Path]:
    """Return shortest path (unweighted) as list of (row, col), or None."""
    b = BFS(grid, start, goal)
    if b.solve():
        return b.path_result
    return None


class BFS:
    def __init__(self, maze, start, goal):
        self.maze = maze
        self.start = start
        self.goal = goal
        
        self.rows = len(maze)
        self.cols = len(maze[0])
        
        self.visited = set()
        self.parents = {}
        self.path_result = []
        self.order = []

    def inbounds(self, r, c):
        return 0 <= r < self.rows and 0 <= c < self.cols

    def free(self, r, c):
        return self.maze[r][c] == 0

    def neighbors(self, r, c):
        directions = [(1,0), (-1,0), (0,1), (0,-1)]
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if self.inbounds(nr, nc) and self.free(nr, nc):
                yield (nr, nc)

    def solve(self):
        queue = deque([self.start])
        self.visited.add(self.start)

        while queue:
            current = queue.popleft()
            self.order.append(current)

            if current == self.goal:
                self.generate_path()
                return True

            for neighbor in self.neighbors(*current):
                if neighbor not in self.visited:
                    self.parents[neighbor] = current
                    self.visited.add(neighbor)
                    queue.append(neighbor)

        return False

    def generate_path(self):
        node = self.goal
        while node != self.start:
            self.path_result.append(node)
            node = self.parents[node]
        self.path_result.append(self.start)
        self.path_result.reverse()
